﻿namespace OOP_Class_exercise
{
    internal class Program
    {
        class Character
        {
            // 필드. 개체가 가지는 데이터
            int level;
            int hp;
            int moveSpeed;
            int atk;

            // 메서드, 개체가 가지는 동작
            public void MoveFront() // 전진
            {
                
            }

            public void MoveBackward() // 후진
            {

            }

            public void TurnLeft() // 좌회전(90도)
            {

            }

            public void TurnRight() // 우회전(90도)
            {

            }

            public void Attack() // 공격
            {

            }

            public void GetDamage() // 피격
            {

            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
